def print_something_local(text):
  print(text)
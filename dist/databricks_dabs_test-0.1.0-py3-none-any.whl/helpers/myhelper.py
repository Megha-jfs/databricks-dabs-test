def print_something(text):
  print(text)